alert(Math.random());
// bug+2
/*
$.evalFile('C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\CSTK\\jsx\1.jsx')
 */