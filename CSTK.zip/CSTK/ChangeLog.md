#Change log#

##Version - 2##
##19-Oct-17##

+Fully workingUpdated for CEP8
+Can set and get debug and log levels
+UI improvements