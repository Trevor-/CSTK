    // $('#openFolderAppBT').click(function() {
    //     var selectFileCallBack = function(newApp) {
    //         if (newApp === '' || newApp === 'null' || newApp === 'undefined') {
    //             return;
    //         }
    //         openFolderApp = newApp;
    //         $('#openFolderApp').text('' + openFolderApp.match(/[^\/\\]+$/));
    //         fs.outputFile(openFolderAppFile, openFolderApp, function() {});
    //     };
    //     jsx.evalFile("fileDialog.jsx", {
    //             baseFolder: '/Applications',
    //             message: "Please select an application for opening Folders shift clicking"
    //         },
    //         selectFileCallBack);
    // });
