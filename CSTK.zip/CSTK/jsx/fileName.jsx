alert('__replaceMe__\n$.fileName: ' + $.fileName + '\n$.__fileName(): ' + $.__fileName() + '\n$.__fileName(\'fileName.jsx\'): ' + $.__fileName('fileName.jsx'));
$.__fileName('fileName.jsx');