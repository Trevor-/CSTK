alert(Math.random());
1 + 2bug + 3
/*
$.evalFile('C:\\Program Files\\Common Files\\Adobe\\CEP\\extensions\\CSTK\\jsx\1.jsx')
/Users/Trevor/repositories/CSTK/com.creative-scripts.cstk/jsx/1.jsx
 */